/** 
 * @file main.cpp
 * @author lcv
 * @date 14 de febrero de 2020, 6:13
 */

#include <iostream>
#include <unistd.h>
#include <time.h>
#include <cmath>
#include <iomanip>
#include "AnsiTerminal.h"

using namespace std;

#define TIME 200000
const string windowFrames[][7]={{"┌","┐","└","┘","─","│","┼"},
                                {"+","+","+","+","-","|","+"}};
const int frame=0;
void wait ( int seconds ){
	clock_t endwait;
	endwait = clock () + seconds * CLOCKS_PER_SEC ;
	while (clock() < endwait) {}
}
void next(){
    setText(white);
    setBackground(black);    
    cout << "Press [Return ]";
    pressReturn();
}
void NyanCat() {
    int colors[]={magenta,red,brown,yellow,green,blue}, ncolors=6, color;

    int h=25, w=80;
    setSize(h,w);
    setText(white);
    setBackground(black);
    clearScreen();
    color=0;
    for (int i=0;i<20;i++) {
        setCursorXY(1,1);
        setBackground(colors[color]);            cout <<":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<endl;
        setBackground(colors[color]);            cout <<":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<endl;
        setBackground(colors[color]);            cout <<":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<endl;
        setBackground(colors[color]);            cout <<":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<endl;
        setBackground(colors[(color+1)%ncolors]);cout <<"::::::::::::::::##############                              :::::::::::::::::::"<<endl;
        setBackground(colors[(color+1)%ncolors]);cout <<"############################  ##############################  :::::::::::::::::"<<endl;
        setBackground(colors[(color+1)%ncolors]);cout <<"#########################  ######???????????????????????######  :::::::::::::::"<<endl;
        setBackground(colors[(color+1)%ncolors]);cout <<"=========================  ####?????????? + ??? + ????????####  :::::::::::::::"<<endl;
        setBackground(colors[(color+2)%ncolors]);cout <<"=========================  ##???? + ?????????????     + ????##  ::::    :::::::"<<endl;
        setBackground(colors[(color+2)%ncolors]);cout <<"------------=============  ##??????????????????  ;;;;  ?????##  ::  ;;;;  :::::"<<endl;
        setBackground(colors[(color+2)%ncolors]);cout <<"-------------------------  ##?????????? + ?????  ;;;;;;?????##    ;;;;;;  :::::"<<endl;
        setBackground(colors[(color+2)%ncolors]);cout <<"-------------------------  ##??????????????????  ;;;;;;         ;;;;;;;;  :::::"<<endl;
        setBackground(colors[(color+3)%ncolors]);cout <<"++++++++++++-------------  ##??????????????????  ;;;;;;;;;;;;;;;;;;;;;;;  :::::"<<endl;
        setBackground(colors[(color+3)%ncolors]);cout <<"+++++++++++++++++++++++++  ##???????????? + ?  ;;;;;;;;;;;;;;;;;;;;;;;;;;;  :::"<<endl;
        setBackground(colors[(color+3)%ncolors]);cout <<"+++++++++++++++++    ;;;;  ##?? + ???????????  ;;;;;;@@  ;;;;;;;;@@  ;;;;;  :::"<<endl;
        setBackground(colors[(color+3)%ncolors]);cout <<"~~~~~~~~~~~~~++++;;;;;;;;  ##????????????????  ;;;;;;    ;;;  ;;;    ;;;;;  :::"<<endl;
        setBackground(colors[(color+4)%ncolors]);cout <<"~~~~~~~~~~~~~~~  ;;  ~~~~  ####?????? + ?????  ;;[];;;;;;;;;;;;;;;;;;;;;[]  :::"<<endl;
        setBackground(colors[(color+4)%ncolors]);cout <<"$$$$$$$$$$$$$~~~~  ~~~~~~  ######?????????????  ;;;;;;              ;;;;  :::::"<<endl;
        setBackground(colors[(color+4)%ncolors]);cout <<"$$$$$$$$$$$$$$$$$$$$$$$$$    ###################  ;;;;;;;;;;;;;;;;;;;;  :::::::"<<endl;
        setBackground(colors[(color+4)%ncolors]);cout <<"$$$$$$$$$$$$$$$$$$$$$$$  ;;;;                                       :::::::::::"<<endl;
        setBackground(colors[(color+5)%ncolors]);cout <<":::::::::::::$$$$$$$$$$  ;;;;  ::  ;;  ::::::::::::  ;;  ::  ;;;;  ::::::::::::"<<endl;
        setBackground(colors[(color+5)%ncolors]);cout <<":::::::::::::::::::::::      ::::::    :::::::::::::     ::::      ::::::::::::"<<endl;
        setBackground(colors[(color+5)%ncolors]);cout <<":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<endl;
        setBackground(colors[(color+5)%ncolors]);cout <<":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"<<endl;
        usleep(TIME);
        color = (color+1)%ncolors;
    }
}

void Cursor() {
    int h=25, w=25;
    setSize(h,w);
    setText(white);
    setBackground(black);
    clearScreen();
    for (int x=1;x<w;x++)
        for (int y=1;y<h;y++) {
            setCursorXY(x,y);
            cout << (x+y)%10;
        }
}


void FunctionXY(int h, int w, double minx, double maxx, double miny, double maxy, double stepx, double stepy, double (*f)(double)=nullptr) {
    int wn=5;
    double ratiox=(maxx-minx)/w,ratioy=(maxy-miny)/h;
    int axisy=(int)((0-minx)/ratiox)+1, axisx=(int)(h-(0-miny)/ratioy)+1;
    setSize(h,w);
    setBackground(black);
    setText(white);
    clearScreen();
    if (axisy >=0 && axisy<w) {
        for (int y=1;y<=h;y++){
            setCursorXY(axisy,y);
            cout << windowFrames[frame][5];
        }
        for (int y=1;y<=h;y++) {
            double realy = maxy - (y-1)*ratioy;
            if ((int)(round(realy*pow(10,wn)))%(int)(round(stepy*pow(10,wn)))==0){
                if (axisy > wn+1) {
                    setCursorXY(axisy-wn,y-1);
                    cout << right << setw(wn) << realy;                    
                    setCursorXY(axisy,y);
                    cout << windowFrames[frame][6];;
                } else {
                    setCursorXY(axisy,y);
                    cout << windowFrames[frame][6];
                    setCursorXY(axisy,y-1);
                    cout <<left << setw(wn) << realy;
                }
            }
        }
    }
    if (axisx >=0 && axisx<h) {
        for (int x=1;x<=w;x++){
            setCursorXY(x, axisx);
            cout << windowFrames[frame][4];
        }
        for (int x=1;x<w;x++) {
            double realx = minx + (x-1)*ratiox;
            if ((int)(round(realx*pow(10,wn)))%(int)(round(stepx*pow(10,wn)))==0){
                setCursorXY(x,axisx);
                cout << windowFrames[frame][6];
                setCursorXY(x,axisx+1);
                cout <<  left <<  setw(wn) << realx;
            }
        }
    }
    setText(lightgreen);
    if (f != nullptr) {
        for (int x=1;x<=w; x+=1) {
            double realx = minx + (x-1)*ratiox, realy=(*f)(realx);
            int y=(int)((maxy-realy)/ratioy)+1;
            if (1<=y && y<=h) {
                setCursorXY(x,y);
                cout << "·"; 
            }
        }
    }
    setCursorXY(1,1);
}
double poly(double x) { return x*x;}
double linear(double x) { return x;}


int main() {
    setCursorOff();
    Cursor();
    next();
    FunctionXY(20,40,-25,25,-25,25,5,5, linear);
    next();
    FunctionXY(60,100,-5,10,-1,1,1,0.1, sin);
    next();
    NyanCat();
    next();
    setText(white);
    setBackground(black);
    setCursorOn();
    return 0;
}

