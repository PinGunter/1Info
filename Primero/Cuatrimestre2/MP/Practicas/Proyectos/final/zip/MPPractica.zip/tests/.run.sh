touch tests//.timeout
CMD="   /home/salvaromero/InfoUni/Primero/Cuatrimestre2/MP/Practicas/Proyectos/final/dist/Debug/GNU-Linux/final  -open data/OPEN_ERROR.data 1> tests//.out9 2>&1"
eval $CMD
rm tests//.timeout
