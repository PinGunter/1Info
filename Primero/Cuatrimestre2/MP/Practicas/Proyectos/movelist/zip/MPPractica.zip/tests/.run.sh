touch tests//.timeout
CMD="   /home/salva/Universidad/Primero/Cuatrimestre2/MP/Practicas/Proyectos/movelist/dist/Debug/GNU-Linux/movelist   1> tests//.out11 2>&1"
eval $CMD
rm tests//.timeout
