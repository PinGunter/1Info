touch tests//.timeout
CMD="   /home/salva/Universidad/Primero/Cuatrimestre2/MP/Practicas/Proyectos/move/dist/Debug/GNU-Linux/move  -l ES -r 100 -i data/OPEN_ERROR.data 1> tests//.out8 2>&1"
eval $CMD
rm tests//.timeout
