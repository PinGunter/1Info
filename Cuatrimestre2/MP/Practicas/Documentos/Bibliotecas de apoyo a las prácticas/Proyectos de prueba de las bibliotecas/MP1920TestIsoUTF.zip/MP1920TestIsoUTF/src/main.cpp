/**
 * @file main.cpp
 * @author DECSAI
 * @note To be implemented by students either completely or by giving them
 * key functions prototipes to guide the implementation
 */

#include <string>
#include <iostream>
#include <cstring>
#include "language.h"
#include "wordlist.h"

using namespace std;


/**
 * @brief Main function. 
 * @return 
 */
int main() {
    string str_utf, str_iso;
    char char_iso, char_utf;
     
    cout << "PRIMER EJEMPLO. TECLEA: HOLA" << endl;
    cin >> str_utf;
    str_iso=toISO(str_utf);
    cout << " UTF8: "<< str_utf << " " <<str_utf.length() << " chars"<< endl;
    cout << " ISO: "<< str_iso << " " <<str_iso.length() << " chars"<< endl;
    cout << " ISO-UTF: "<< toUTF(str_iso) << " " <<str_iso.length() << " chars"<< endl;

    cout <<endl<< "SEGUNDO EJEMPLO. TECLEA: CAÑÓN" << endl;
    cin >> str_utf;
    str_iso=toISO(str_utf);
    cout << " UTF8: "<< str_utf << " " <<str_utf.length() << " chars"<< endl;
    cout << " ISO: "<< str_iso << " " <<str_iso.length() << " chars"<< endl;
    cout << " ISO-UTF: "<< toUTF(str_iso) << " " <<str_iso.length() << " chars"<< endl;


    cout <<endl<< "TERCER EJEMPLO. TECLEA: Ñ" << endl;
    cin >> str_utf; // No es posible leer en un char porque ocupa más de un byte
    char_iso=toISO(str_utf)[0];
    cout << " UTF8: "<< toUTF(char_iso) << " " <<str_utf.length() << " chars"<< endl<< endl; 
    cout << " ISO: "<<char_iso << endl; 
    cout << " ISO-UTF8: "<<toUTF(char_iso) << endl; 

}


//    Bag bag;
//    string word, lang;
//    int Id, count, max, maxId;
//    
////    cout << "ALPHABET: "<<toUTF(ALPHABET)<< endl;
////    cout << "LANGUAGE: "<<language.getLanguage()<<endl;
//    cout << "TYPE LANGUAGE: ";
//    cin >> lang;
//    Language language(lang);
//    cout << "ALLOWED LETTERS: " << toUTF(language.getLetterSet()) <<endl;
//    cout << "TYPE SEED (<0 RANDOM): ";
//    cin >> Id;
////    max = 0; maxId=0;
////    for (Id=0;Id<100000;Id++) {
//    if (Id >= 0)
//        bag.setRandom(Id);
//    bag.define(language);
//    count = 0;
//    cout << "BAG ("<<Id<<"-"<<bag.size()<<") : "<<toUTF(bag.to_string())<< endl;
//    do {
////        word = bag.extract(5);
////        cout << toUTF(word);
//        cout << "Type word: ";
//        cin >> word;
//        word = normalizeWord(word);
//        cout << "Normalized: "<<toUTF(word);
//        if (language.query(word)) {
//            count++;
//            cout <<" ***";
//        }
//        cout << endl;
//    }while (word != "FIN");
//    cout << count << " words found for "<<Id << endl;
////    if (count > max) { max = count; maxId = Id;}
////    }
////    cout << "MAX "<<max<< " en "<<maxId<<endl;
//    return 0;
//    // ES 16, 28, 62, 136(2), 60143 (3)
//    // EN 8784 (3)
//    // FR 66727 (3)
//}

